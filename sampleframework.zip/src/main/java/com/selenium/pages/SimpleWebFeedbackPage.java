package com.selenium.pages;

public class SimpleWebFeedbackPage {

}
