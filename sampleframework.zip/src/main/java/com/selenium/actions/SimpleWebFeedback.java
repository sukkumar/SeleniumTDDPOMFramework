package com.selenium.actions;

public class SimpleWebFeedback {

}
