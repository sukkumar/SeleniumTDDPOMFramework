package com.selenium.base;

public class BasePage {

}
