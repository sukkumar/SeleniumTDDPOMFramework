package com.selenium.base;

public class BaseTest {

}
